import React from "react";
const Procontext = React.createContext()
export default Procontext;