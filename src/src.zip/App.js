import { BrowserRouter, Routes, Route } from "react-router-dom";
import React, { useState } from "react";
import "./App.css";
import Footer from "./Footer/Footer.js";
import Home from "./Home/Home.js";
import Navbar from "./Navbar/Navbar";
import Electronics from "./Electronics/Electronics";
import Jawlery from "./Jawlery/Jawlery";
import Mansclothing from "./Mansclothing/Mansclothing";
import Womansclothing from "./Womansclothing/Womansclothing";
import Login from "./Login/Login";
import SignUp from "./SignUp/SignUp";
import store from "./redux/store";
import "bootstrap/dist/js/bootstrap.bundle";
import "animate.css";
import { Provider } from "react-redux";
function App() {
  const [myid, setmyid] = useState(0);
  const hallo = (id) => {
    setmyid(id);
  };
  return (
    <>
      <BrowserRouter>
        <Provider store={store}>
          {/* <Header /> */}
          <Navbar />
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route exact path="/Electronics" element={<Electronics />} />
            <Route path="/Jawlery" element={<Jawlery />} />
            <Route path="/Mansclothing" element={<Mansclothing />} />
            <Route path="/Womansclothing" element={<Womansclothing />} />
            <Route exact path="/Login" element={<Login />} />
            <Route path="/Signup" element={<SignUp />} />
            <Route path="/LogOut" element={<Home />} />
          </Routes>
          <Footer />
        </Provider>
      </BrowserRouter>
    </>
  );
}

export default App;
