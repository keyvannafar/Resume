import { combineReducers } from "redux";
import ButtonDes from "./ButtonDes";
import LanChange from "./LanChange";
import LoginReducer from "./LoginReducer";
const reducer = combineReducers({
  ButtonDes,
  LanChange,
  LoginReducer,
});

export default reducer;