import "../Contact/Contact.css";
import {formDataEnglish, formDataDeutsch} from "./ContactFormData/contactData.js";
import {personalData} from "../CV/ButtonData/dataPersonal";
import FormContact from "./ContactFormData";
import { useSelector } from "react-redux";
function Contact() {
  const Language = useSelector((state)=> state.LanChange.Language)
  return (
    <div>
      {Language == true
        ? formDataEnglish.map((item) => <FormContact key={item.id} {...item} />)
        : formDataDeutsch.map((item) => (
            <FormContact key={item.id} {...item} />
          ))}
    </div>
  );
}

export default Contact;
