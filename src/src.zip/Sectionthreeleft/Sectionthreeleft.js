import "./Sectionthreeleft.css";
import slide2 from "../images/Keyvan-photo/keyvan-coat.jpg";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import {DataDes} from "./Button-int/data";
import { DataDesEnglisch } from "./Button-int/data";
import IntButton from "./Button-int";
function Sectionthreeleft() {
  //################## Redux  ###########################
  const Id = useSelector((state) => state.ButtonDes.Id);
  const Language = useSelector((state) => state.LanChange.Language);
  // const ButtonDes = useDispatch();
  //################## Redux  ###########################
  // function personal() {

  //   ButtonDes({ type: "personal" });
  // }
  //  function Beruflicher() {
  //    ButtonDes({ type: "Beruflicher" });
  //  }
  // function Ausbildung() {
  //   ButtonDes({ type: "Ausbildung" });
  // }
  // function Kenntnisse() {
  //   ButtonDes({ type: "Kenntnisse" });
  // }
  return (
    <>
      <div className="leftthree">
        <img className="image-int" src={slide2} />
        {Language == false
          ? DataDes.map((item) => <IntButton key={item.id} {...item} />)
          : DataDesEnglisch.map((item) => <IntButton key={item.id} {...item} />)}

        
      </div>
    </>
  );
}

export default Sectionthreeleft;
