import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
//import "bootstrap/dist/js/bootstrap.min.js";
import "bootstrap-icons/font/bootstrap-icons.css";
import "./Card.css";
function Card({ id, title, des, price, image, click, cat }) {
  const [qty, setqty] = useState(1);
  const [Fav, setFav] = useState(false);
  const [addtocart, setAddtocart] = useState(false);
  const plus = () => {
    if (qty < 9) {
      setqty(qty + 1);
    }
  };
  const minus = () => {
    if (qty > 0) {
      setqty(qty - 1);
    }
  };
  function addToCart() {
    click(id);
    setAddtocart(!addtocart);
  }

  function toggleFav() {
    setFav(!Fav);
  }
  if (cat == "women's clothing") {
    return (
      <div className="col">
        <div className="card h-100 wow fadeInUp">
          <img src={image} className="card-img-top fadeInUp" alt="products" />
          <div className="card-body">
            <h5 className="card-title">{title}</h5>
            <p className="card-text">{des}</p>
            <p>{price}$</p>
          </div>
          <div className="addqty">
            <div className="addqty-1">
              <div class={"float-left"}>
                {Fav == false ? (
                  <i class="bi bi-heart" onClick={toggleFav}></i>
                ) : (
                  <i
                    class="bi bi-heart-fill text-danger"
                    onClick={toggleFav}
                  ></i>
                )}
              </div>
              <button className="btn-1" onClick={minus}>
                -
              </button>
              <div className="text-center">{qty}</div>
              <button className="btn-1" onClick={plus}>
                +
              </button>
            </div>
          </div>
          <button
            className={`btn-primary ${qty == 0 ? "opacity-25" : "bg"} ${
              addtocart ? "opacity-100" : "bg"
            }`}
            onClick={addToCart}
          >
            add to cart
          </button>
          <div className="card-footer">
            <small className="text-muted">Last updated 3 mins ago</small>
          </div>
        </div>
      </div>
    );
  }
}

export default Card;
