import "./Header.css";
import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";
function Header() {
  // const [Login, setLogin] = useState(false);
  // const [Sgn, setSgn] = useState(false);
  // const [Lan, setLan] = useState(false);
  // function toggleLogin() {
  //   setLogin(!Login);
  //   console.log("kivi");
  // }
  // function toggleLan() {
  //   setLan(!Lan);
  //   console.log("kivi");
  // }
  // function sgn() {
  //   setSgn(!Sgn);
  // }
  return (
    <>
      <nav className="navbar navbar-light header border-bottom">
        <div className="container-fluid container">
          <a className="navbar-brand text-white">
            <h2 className="logo_title">Keyvan Nafarzadeh</h2>
          </a>
          <form className="d-flex">
            <button className="btn nav-item dropdown border-1">
              <a
                class="dropdown-toggle text-white"
                href="#"
                id="navbarDropdown"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              ></a>

              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <Link class="dropdown-item" to="#">
                    De
                  </Link>

                  <Link class="dropdown-item" to="#">
                    En
                  </Link>
                </li>
              </ul>
            </button>

            <button className="btn nav-item dropdown me-2">
              <Link
                class="dropdown-toggle text-white"
                to="#"
                id="navbarDropdown"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                <i class="bi bi-person-fill"></i>
              </Link>

              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                <li>
                  <Link class="dropdown-item" to="/Login">
                    Login
                  </Link>

                  <Link class="dropdown-item" to="/LogOut">
                    LogOut
                  </Link>
                </li>
                <li>
                  <Link class="dropdown-item" to="SignUp">
                    Sign up
                  </Link>

                  <Link class="dropdown-item" to="SignUp"></Link>
                </li>
                <li>
                  <hr class="dropdown-divider" />
                </li>
                <li>
                  <a class="dropdown-item" href="#">
                    Something else here
                  </a>
                </li>
              </ul>
            </button>
            <input
              className="form-control me-0 search_form"
              type="search"
              placeholder="Search"
              aria-label="Search"
            />

            <button
              className="btn btn-outline-success text-white ms-0"
              type="submit"
            >
              <i class="bi bi-search text-white"></i>
            </button>
          </form>
        </div>
      </nav>
    </>
  );
}

export default Header;
