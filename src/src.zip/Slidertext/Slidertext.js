import { useSelector } from "react-redux";
import "./Slidertext.css";

function Slidertext() {
  const Language = useSelector((state) => state.LanChange.Language)
  return (
    <>
      <div className="slidertext ">
        <h1 className="fade_h1">M.M.Nafarzadeh</h1>
        <br />
        <br />
        {/* <p className="fade_text_slider">
          Diese Website dient dazu, Sie besser kennenzulernen
        </p> */}
        {Language == false ? (
          <div>
            <p className="fade_text_slider">
              Gemeinsam werden wir einige Programmiersprachen für die
              Website-Entwicklung sehen
            </p>
            <p className="fade_text_slider">
              Und ich werde ein wenig über meine Erfahrungen und das, was ich
              gelernt habe, erzählen
            </p>
            <p className="fade_text_slider">Lass uns anfangen</p>
            <a className="nav-link" aria-current="page" href="#contact">
              <button className="btn btn-primary mb-2 contact-btn">
                Kontakt
              </button>
            </a>
          </div>
        ) : (
          <div>
            <p className="fade_text_slider">
              Together we will use some programming languages ​​for the see
              website development
            </p>
            <p className="fade_text_slider">
              And I'll tell a little bit about my experiences and what I do
              learned to tell
            </p>
            <p className="fade_text_slider">Let's start</p>
            <a className="nav-link" aria-current="page" href="#contact">
              <button className="btn btn-primary mb-2 contact-btn">
                Contact 
              </button>
            </a>
          </div>
        )}
      </div>
    </>
  );
}

export default Slidertext;
