



import Card3 from "../Card/Card3.js";
import react, { useState } from "react";
import { products } from "../data.js";

function Jawlery() {
  const [myid, setmyid] = useState(0);
  const hallo = (id) => {
    setmyid(id);
  };
  return (
    <>
      <p>{myid}</p>
      <div className="container">
        <div className="row row-cols-1 row-cols-md-3 row-cols-lg-4 g-4">
          {products.map((item) => (
            <Card3
              Key={item.id}
              image={item.image}
              title={item.title}
              price={item.price}
              cat={item.category}
              //des={item.description}
              {...item}
              click={hallo}
            />
          ))}
        </div>
      </div>
    </>
  );
}

export default Jawlery;
