import Sectiontwo from "../Sectiontwo/Sectiontwo";
import Sectionthree from "../Sectionthree/Sectionthree"
import Slidersection from "../Slidersection/Slidersection";
import Contact from "../Contact/Contact";
import "../Home/Home.css"
import Procontext from "../Context/Procontext";
import { useState,useContext } from "react";
import store from "../redux/store";
import { Provider } from "react-redux/es/exports";
function Home() {
  const [Pro, setPro] = useState(1);
  const [Cvid, setCvid] = useState(1);
  return (
    <>
      <Procontext.Provider value={[Pro, setPro]}>
        <Provider store={store}>
          <Slidersection />
          <Sectiontwo />
          <Sectionthree />
          <Contact />
        </Provider>
      </Procontext.Provider>
    </>
  );
}
export default Home;
