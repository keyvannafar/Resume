import "../Introduce/Introduce.css";

function Introduce() {
  return (
    <div className="parallex-1 introduce">
      <div className="container int">
        <h2>Hallo</h2><br />
        <p>
          Willkommen liebe Benutzer Der Zweck dieser Website ist nicht zu
          unterrichten. <br />
          Vielmehr geht es darum, die Programmier- und
          Content-Management-Methoden vorzustellen, mit denen ich gearbeitet
          habe
        </p>
      </div>
    </div>
  );
}

export default Introduce;
