import logoWordpress from "../../../src/images/logo/wordpress-logo.png";
import logoReact from "../../../src/images/logo/React.png";
import logoJoomla from "../../../src/images/logo/joomla-logo.png";
import logoHtml from "../../../src/images/logo/html-5.png";
import logoCss from "../../../src/images/logo/css-3.png";
import logoPhp from "../../../src/images/logo/php.png";
export const dataButton = [
  {
    id: 1,
    text: "React",
    image: logoReact,
  },
  {
    id: 7,
    text: "JavaScript",
    image: logoPhp,
  },
  {
    id: 6,
    text: "Php",
    image: logoPhp,
  },
  {
    id: 2,
    text: "Html",
    image: logoHtml,
  },

  {
    id: 5,
    text: "Css",
    image: logoCss,
  },

  {
    id: 3,
    text: "Joomla",
    image: logoJoomla,
  },
  {
    id: 4,
    text: "Wordpress",
    image: logoWordpress,
  },
];