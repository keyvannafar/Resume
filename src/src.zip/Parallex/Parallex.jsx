import "../Parallex/Parallex.css";
import Parallax from "../images/Parallax/Parallax.jpg"
function Parallex() {
  return (
    <div class="fluid_container">
  <div class="parallax">
   <div id="group1" class="parallax__group">
     <div class="parallax__layer parallax__layer--back">
      <img class="codepen_image" src="https://assets.codepen.io/assets/logos/codepen-logo.svg" />
     </div>
   </div>
   <div class="parallax__group">
    <div class="parallax__layer parallax__layer--base">
     <div class="jumbotron" >  
      <h1>Bootstrap</h1>
      <h3>Loaded from the <span class="glyphicon glyphicon-cloud"></span> cloud right here on Codepen</h3>    
     </div>
  
    <div class="container">
        <div class="row">
          <div class="col-sm-6"> 
            <h2>About</h2>
            <p>This example demonstrates how easy it is to get up and running with Bootstrap.
          You can load bootstrap on your own server, or from the cloud @ <a href="https://www.bootstrapcdn.com/">BootstrapCDN</a> as I'm doing so here in this example.</p>
          </div>
          
          <div class="col-sm-6">        
            <h2 class="cow">Holy Cow</h2>
            <p>Bootstrap components make it easy to create responsive templates without having to write hardly any css.</p>
            <p>SAY WHAT!</p>
        </div>
      </div>
      
      <div class="row"> 
        <div class="col-sm-2">
          <h3>Rows</h3>
          <p>This is the first column contained in a row, rows are defined by a CSS class called <strong>row</strong></p>
        </div>
        <div class="col-sm-2">
          <h3>Columns</h3>
          <p>This is the second column in the row.  Each row can have up to a number of 12 columns</p>
        </div>
        <div class="col-sm-2">
          <h3>Numbers</h3>
          <p>This is the third column, and takes up the width of 2 out of 12 possible columns.</p>
        </div>
        <div class="col-sm-2">
          <h3>Component</h3>
          <p>Bootstrap has predefined CSS classes in order to easily setup columns.  There are also many reusable components built-in to provide dropdowns, input groups, navigation, alerts, iconography, and much more.</p>
        </div>
        <div class="col-sm-2">
          <h3>Define</h3>
          <p>Each column in this row takes up 2 out of 12 columns possible. This is defined by the CSS class <strong>.col-sm-2</strong></p>
        </div>
        <div class="col-sm-2">
          <h3>Also</h3>
          <p>If you wanted, let's say, 3 columns in a row, you would use this CSS class <strong>.col-sm-4</strong>.  Below is another example of that happening.  You can find out more about components <a href="https://getbootstrap.com/components/">here</a></p>
        </div>
      </div>
      <br />
       <div class="row">
        <div class="col-sm-4">
          <h1>One</h1>
          <p>Domestic confined any but son bachelor advanced remember. How proceed offered her offence shy forming. Returned peculiar pleasant but appetite differed she. Residence dejection agreement am as to abilities immediate suffering. Ye am depending propriety sweetness distrusts belonging collected. Smiling mention he in thought equally musical. Wisdom new and valley answer. Contented it so is discourse recommend. Man its upon him call mile. An pasture he himself believe ferrars besides cottage.</p>
        </div>
         <div class="col-sm-4">
           <h1>Two</h1>
          <p>There worse by an of miles civil. Manner before lively wholly am mr indeed expect. Among every merry his yet has her. You mistress get dashwood children off. Met whose marry under the merit. In it do continual consulted no listening. Devonshire sir sex motionless travelling six themselves. So colonel as greatly shewing herself observe ashamed. Demands minutes regular ye to detract is. </p>
        </div>
         <div class="col-sm-4">
           <h1>Three</h1>
          <p>Spot of come to ever hand as lady meet on. Delicate contempt received two yet advanced. Gentleman as belonging he commanded believing dejection in by. On no am winding chicken so behaved. Its preserved sex enjoyment new way behaviour. Him yet devonshire celebrated especially. Unfeeling one provision are smallness resembled repulsive. </p>
        </div>
      </div>
      <br />
      
     </div>

      
      
     </div>
    </div>
   </div>
 </div>
  );
}

export default Parallex;
