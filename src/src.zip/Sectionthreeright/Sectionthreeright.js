import "./Sectionthreeright.css";
import PersonalData from "../CV/ButtonData";
import { useSelector } from "react-redux";
import CV from "../CV/CV";
function Sectionthreeright() {
  //const personalId = useSelector((state)=> state.ButtonDes.personalId)
  //alert(personalId)
  return (
    <div className="rightthree ">  
        <CV />
    </div>
  );
}

export default Sectionthreeright;
